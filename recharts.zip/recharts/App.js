import React from "react";
import Navbar from "./Navbar";
import { red } from "@mui/material/colors";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { alpha, Box, styled } from "@mui/system";
import { Grid } from "@mui/material";
import FeedbackTable from "./FeedbackTable";
import SourceCount from "./SourceCount";
import SentimentScore from "./SentimentScore";
import OverallSatisfaction from "./OverallSatisfaction";
import InputBase from "@mui/material/InputBase";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import FeedbackCount from "./FeedbackCount";
import MonthlySourceCount from "./MonthlySourceCount";
import MonthlySentimentDistribution from "./MonthlySentimentDistribution";

const theme = createTheme({
  palette: {
    primary: {
      main: "#040404e8",
    },
  },
});
const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(1),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(5)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      width: "12ch",
      "&:focus": {
        width: "20ch",
      },
    },
  },
}));

function App() {
  let data = {
    monthlyFeedbackCount: {
      jan: "20",
      feb: "10",
      mar: "30",
      apr: "40",
      may: "50",
      jun: "20",
      jul: "15",
      aug: "12",
      sep: "22",
      oct: "32",
      nov: "43",
      dec: "55",
    },
    sourceWiseDistribution: {
      jan: { liveAgent: "30", ssp: "20" },
      feb: { liveAgent: "25", ssp: "25" },
      mar: { liveAgent: "25", ssp: "35" },
      apr: { liveAgent: "22", ssp: "33" },
      may: { liveAgent: "24", ssp: "43" },
      jun: { liveAgent: "40", ssp: "20" },
      jul: { liveAgent: "20", ssp: "10" },
      aug: { liveAgent: "25", ssp: "45" },
      sep: { liveAgent: "10", ssp: "10" },
      oct: { liveAgent: "20", ssp: "30" },
      nov: { liveAgent: "5", ssp: "20" },
      dec: { liveAgent: "30", ssp: "30" },
    },
    sentimentWiseDistribution: {
      jan: {
        happy: "20",
        excited: "30",
        neutral: "25",
        sad: "15",
        angry: "10",
      },
      feb: {
        happy: "25",
        excited: "25",
        neutral: "30",
        sad: "10",
        angry: "10",
      },
      mar: { happy: "10", excited: "20", neutral: "10", sad: "5", angry: "2" },
      apr: { happy: "20", excited: "10", neutral: "20", sad: "10", angry: "5" },
      may: { happy: "30", excited: "30", neutral: "30", sad: "15", angry: "7" },
      jun: { happy: "20", excited: "25", neutral: "40", sad: "5", angry: "10" },
      jul: { happy: "30", excited: "5", neutral: "30", sad: "10", angry: "20" },
      aug: {
        happy: "40",
        excited: "15",
        neutral: "20",
        sad: "15",
        angry: "30",
      },
      sep: { happy: "25", excited: "60", neutral: "10", sad: "2", angry: "5" },
      oct: { happy: "35", excited: "12", neutral: "5", sad: "20", angry: "10" },
      nov: { happy: "21", excited: "14", neutral: "15", sad: "15", angry: "2" },
      dec: { happy: "10", excited: "5", neutral: "25", sad: "5", angry: "1" },
    },
    feedbackSourceCount: {
      liveAgent: "60",
      ssp: "40",
    },
    feedbackRatingCount: {
      neutral: "20",
      excited: "25",
      sad: "15",
      happy: "30",
      angry: "10",
    },
    custFeedbackList: [
      {
        sessionId: "aec13cfe-d4b2-483f-a31d-e6a78084179f",
        agentName: "Jose",
        createTimestamp: "2022-07-07T19:36:51.535",
        customerEmail: null,
        customerName: "Dhoni",
        customerPhone: null,
        feedbackInput: "",
        feedbackRating: "happy",
        source: "live agent",
      },
      {
        sessionId: "aec13cfe-d4b2-483f-a31d-e6a78084179f",
        agentName: "Jose",
        createTimestamp: "2022-08-15T19:36:51.535",
        customerEmail: null,
        customerName: "Kohli",
        customerPhone: null,
        feedbackInput: "",
        feedbackRating: "happy",
        source: "ssp",
      },
    ],
  };

  return (
    <ThemeProvider theme={theme}>
      <Box
        sx={{
          background: "#383737",
          overflow: "hidden",
          paddingBottom: "20px",
        }}
      >
        <Navbar />
        <Box sx={{ margin: "30px" }}>
          <Grid container rowGap={2}>
            <Grid item container sm={12} md={6}>
              <Grid item sm={6}>
                <label style={{ color: "white" }}>From Date: &nbsp; </label>
                <input
                  type="date"
                  name="fromDate"
                  style={{
                    height: "40px",
                    background: "rgba(255, 255, 255, 0.15)",
                    border: "none",
                    color: "rgba(255, 255, 255, 0.55)",
                    padding: "0 10px",
                    borderRadius: "5px",
                    fontFamily: "inherit",
                    width: "250px",
                    maxWidth: "60%",
                  }}
                />
              </Grid>
              <Grid item sm={6}>
                <label style={{ color: "white" }}>To Date: &nbsp; </label>
                <input
                  type="date"
                  name="toDate"
                  style={{
                    height: "40px",
                    background: "rgba(255, 255, 255, 0.15)",
                    border: "none",
                    color: "rgba(255, 255, 255, 0.55)",
                    padding: "0 10px",
                    borderRadius: "5px",
                    fontFamily: "inherit",
                    width: "250px",
                    maxWidth: "60%",
                  }}
                />
              </Grid>
            </Grid>
            <Grid item sm={12} md={3}>
              <Search>
                <SearchIconWrapper>
                  <SearchIcon />
                </SearchIconWrapper>
                <StyledInputBase
                  placeholder="Search…"
                  inputProps={{ "aria-label": "search" }}
                />
              </Search>
            </Grid>
          </Grid>
        </Box>
        <Box sx={{ margin: "10px 30px" }}>
          <Grid container sx={{ color: "white", marginBottom: "20px" }}>
            <Grid
              item
              xs={12}
              sm={6}
              md={4}
              lg={4}
              sx={{ padding: "0px 10px 10px 0", height: "90%" }}
            >
              <Box
                sx={{
                  border: "1px solid white",
                  padding: "10px",
                  borderRadius: "5px",
                  height: "320px",
                }}
              >
                <SourceCount fbData={data} />
              </Box>
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              md={4}
              lg={4}
              sx={{ padding: "0px 10px 10px 0", height: "90%" }}
            >
              <Box
                sx={{
                  border: "1px solid white",
                  padding: "10px",
                  borderRadius: "5px",
                  height: "320px",
                }}
              >
                <SentimentScore fbData={data} />
              </Box>
            </Grid>
            <Grid
              item
              xs={12}
              sm={12}
              md={4}
              lg={4}
              sx={{ padding: "0px 10px 10px 0", height: "90%" }}
            >
              <Box
                sx={{
                  border: "1px solid white",
                  padding: "10px",
                  borderRadius: "5px",
                  height: "320px",
                }}
              >
                <OverallSatisfaction fbData={data} />
              </Box>
            </Grid>
            <Grid
              item
              xs={12}
              sm={12}
              md={12}
              lg={6}
              sx={{ padding: "0px 10px 10px 0", height: "90%" }}
            >
              <Box
                sx={{
                  border: "1px solid white",
                  padding: "10px",
                  borderRadius: "5px",
                  height: "320px",
                }}
              >
                <FeedbackCount fbData={data} />
              </Box>
            </Grid>
            <Grid
              item
              xs={12}
              sm={12}
              md={12}
              lg={6}
              sx={{ padding: "0px 10px 10px 0", height: "90%" }}
            >
              <Box
                sx={{
                  border: "1px solid white",
                  padding: "10px",
                  borderRadius: "5px",
                  height: "320px",
                }}
              >
                <MonthlySourceCount fbData={data} />
              </Box>
            </Grid>
            <Grid
              item
              xs={12}
              sm={12}
              md={12}
              lg={6}
              sx={{ padding: "0px 10px 10px 0", height: "90%" }}
            >
              <Box
                sx={{
                  border: "1px solid white",
                  padding: "10px",
                  borderRadius: "5px",
                  height: "320px",
                }}
              >
                <MonthlySentimentDistribution fbData={data} />
              </Box>
            </Grid>
          </Grid>
          <FeedbackTable fbData={data} />
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;
