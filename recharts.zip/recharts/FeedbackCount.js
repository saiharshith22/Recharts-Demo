import { Typography } from "@mui/material";
import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Dot,
  CartesianGrid,
} from "recharts";

const LineGraph = ({ data }) => {
  return (
    <LineChart
      width={600}
      height={260}
      data={data}
      margin={{
        top: 10,
        right: 10,
        left: 10,
        bottom: 20,
      }}
    >
      <XAxis
        dataKey="name"
        label={{
          value: "Feedback Reaction",
          position: "bottom",
          offset: 0,
          style: { fontSize: 16, fill: "#666", color: "red" },
        }}
      />
      <YAxis
        label={{
          value: "Feedback Count",
          angle: -90,
          offset: 20,
          position: "insideBottomLeft",
          style: { fontSize: 16, fill: "#666" },
        }}
      />
      <Tooltip />
      {/* <Legend /> */}
      {/* <CartesianGrid strokeDasharray="5 5" /> */}
      <Line type="monotone" dataKey="value" stroke="#8884d8" />

      <Dot label={({ payload, index }) => payload[index].name} />
    </LineChart>
  );
};

const FeedbackCount = ({ fbData }) => {
  const { monthlyFeedbackCount } = fbData;
  const data = Object.entries(monthlyFeedbackCount).map(([name, value]) => ({
    name,
    value: Number(value),
  }));

  return (
    <>
      <Typography
        sx={{
          fontSize: "22px",
          fontWeight: 700,
          marginBottom: "20px",
        }}
      >
        Feedback Count
      </Typography>
      <ResponsiveContainer width={250} height={260}>
        <LineGraph data={data} />
      </ResponsiveContainer>
    </>
  );
};

export default FeedbackCount;
