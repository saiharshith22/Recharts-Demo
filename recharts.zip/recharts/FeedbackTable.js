import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Box } from "@mui/system";
import { Button, Typography } from "@mui/material";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

export default function FeedbackTable({ fbData }) {
  const { custFeedbackList } = fbData;

  let rows = custFeedbackList.map((obj, index) => ({
    name: obj.customerName,
    feedbackDate: obj.createTimestamp,
    feedbackText: obj.source,
    feedbackRating: 5,
  }));
  const getDate = (dateString) => {
    const date = new Date(dateString);
    const options = { year: "numeric", month: "short", day: "numeric" };
    const formattedDate = date.toLocaleDateString("en-US", options);
    const dayOfWeek = date.toLocaleDateString("en-US", { weekday: "long" });
    const result = `${formattedDate} ${dayOfWeek}`;
    return result;
    console.log(result);
  };
  return (
    <>
      <Box
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "space-between",
          marginBottom: "5px",
        }}
      >
        <Typography
          sx={{
            color: "white",
            margin: 0,
            fontSize: "20px",
            fontWeight: 700,
          }}
        >
          Feedback Summary
        </Typography>
        <Button
          sx={{
            // marginBottom: "5px",
            // marginLeft: "auto",
            // display: "block",
            textTransform: "none",
            "&:hover": {
              opacity: "0.6",
            },
          }}
          variant="contained"
        >
          Export
        </Button>
      </Box>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell align="center">Name</StyledTableCell>
              <StyledTableCell align="center">FeedbackDate</StyledTableCell>
              <StyledTableCell align="center">FeedbackText</StyledTableCell>
              <StyledTableCell align="center">FeedbackRating</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <StyledTableRow key={row.name}>
                <StyledTableCell component="th" align="center" scope="row">
                  {row.name}
                </StyledTableCell>
                <StyledTableCell align="center">
                  {getDate(row.feedbackDate)}
                </StyledTableCell>
                <StyledTableCell align="center">
                  {row.feedbackText}
                </StyledTableCell>
                <StyledTableCell align="center">
                  {row.feedbackRating}
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
