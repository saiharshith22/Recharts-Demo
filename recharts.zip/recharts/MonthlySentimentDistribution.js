import React from "react";
import { Typography } from "@mui/material";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

const MonthlySentimentDistribution = ({ fbData }) => {
  const { sentimentWiseDistribution } = fbData;
  const data = Object.keys(sentimentWiseDistribution).map((month) => {
    return {
      month: month,
      ...sentimentWiseDistribution[month],
    };
  });
  return (
    <>
      <Typography
        sx={{
          fontSize: "22px",
          fontWeight: 700,
          marginBottom: "20px",
        }}
      >
        Monthly Sentiment Distribution
      </Typography>
      <LineChart width={600} height={270} data={data}>
        <XAxis dataKey="month" />
        <YAxis />
        <CartesianGrid strokeDasharray="3 3" />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="happy" stroke="#8884d8" />
        <Line type="monotone" dataKey="excited" stroke="#82ca9d" />
        <Line type="monotone" dataKey="neutral" stroke="#ffc658" />
        <Line type="monotone" dataKey="sad" stroke="#ff7300" />
        <Line type="monotone" dataKey="angry" stroke="#f00" />
      </LineChart>
    </>
  );
};

export default MonthlySentimentDistribution;
