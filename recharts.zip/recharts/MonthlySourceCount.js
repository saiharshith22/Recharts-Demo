import { Typography } from "@mui/material";
import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";

const MonthlySourceCount = ({ fbData }) => {
  const { sourceWiseDistribution } = fbData;
  const data = Object.entries(sourceWiseDistribution).map(
    ([month, distribution]) => ({
      month,
      liveAgent: parseInt(distribution.liveAgent),
      ssp: parseInt(distribution.ssp),
    })
  );
  return (
    <>
      <Typography
        sx={{
          fontSize: "22px",
          fontWeight: 700,
          marginBottom: "20px",
        }}
      >
        Monthly Source Distribution
      </Typography>
      <BarChart
        width={600}
        height={260}
        data={data}
        margin={{
          top: 10,
          right: 10,
          left: 10,
          bottom: 20,
        }}
      >
        <XAxis
          dataKey="month"
          label={{
            value: "Months",
            position: "bottom",
            offset: 0,
            style: { fontSize: 16, fill: "#666", color: "red" },
          }}
        />
        <YAxis
          label={{
            value: "Feedback Count",
            angle: -90,
            offset: 20,
            position: "insideBottomLeft",
            style: { fontSize: 16, fill: "#666" },
          }}
        />
        <Tooltip />
        <Bar dataKey="liveAgent" fill="#8884d8" />
        <Bar dataKey="ssp" fill="#82ca9d" />
      </BarChart>
    </>
  );
};

export default MonthlySourceCount;
