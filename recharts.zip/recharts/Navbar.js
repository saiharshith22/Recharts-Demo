import * as React from "react";
import { styled, alpha } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";

import { Avatar, TextField } from "@mui/material";

export default function Navbar() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Box sx={{ flexGrow: 0.5 }}>
            <IconButton sx={{ marginRight: "10px" }}>
              <Avatar alt="Oriental Logo" src="/static/images/avatar/2.jpg" />
            </IconButton>
          </Box>
          <Typography sx={{ fontWeight: 700, fontSize: "22px" }}>
            CUSTOMER FEEDBACK ANALYSIS
          </Typography>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
