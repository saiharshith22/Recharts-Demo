import { Typography } from "@mui/material";
import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Label } from "recharts";

export default function OverallSatisfaction({ fbData }) {
  const RADIAN = Math.PI / 180;
  const {
    feedbackRatingCount: { happy, excited },
  } = fbData;
  let per = Number(happy) + Number(excited);
  const data = [
    { name: "A", value: per, color: "rgb(0 ,136 ,254,0.6)" },
    { name: "A", value: 100 - per, color: "rgb(0 ,136 ,254)" },
  ];
  const cx = 150;
  const cy = 150;
  const iR = 100;
  const oR = 120;

  const needle = (data, cx, cy, iR, oR, color) => {
    let total = 100 - per;
    const ang = 180.0 * (total / 100);
    const length = (iR + 2 * oR) / 3;
    const sin = Math.sin(-RADIAN * ang);
    const cos = Math.cos(-RADIAN * ang);
    const r = 5;
    const x0 = cx + 5;
    const y0 = cy + 5;
    const xba = x0 + r * sin;
    const yba = y0 - r * cos;
    const xbb = x0 - r * sin;
    const ybb = y0 + r * cos;
    const xp = x0 + length * cos;
    const yp = y0 + length * sin;

    return [
      <circle
        cx={x0}
        cy={y0}
        r={r}
        fill={"rgb(0, 136, 254, 0.5)"}
        stroke="none"
      />,
      <path
        d={`M${xba},${yba}L${xbb},${ybb},L${xp},${yp},L${xba},${yba}`}
        stroke="rgb(0, 136, 254)"
        fill={"rgb(0, 136, 254, 0.5)"}
      />,
    ];
  };
  return (
    <>
      <Typography
        sx={{
          fontSize: "22px",
          fontWeight: 700,
          marginBottom: "20px",
        }}
      >
        Overall Satisfaction
      </Typography>
      <ResponsiveContainer width={300} height={300}>
        <PieChart>
          <Pie
            dataKey="value"
            startAngle={180}
            endAngle={0}
            data={data}
            cx={cx}
            cy={cy}
            innerRadius={iR}
            outerRadius={oR}
            fill="#8884d8"
            stroke="grey"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
            <Label value={`${data[0].value}%`} offset={20} position="outside" />
          </Pie>
          {needle(data, cx, cy, iR, oR, "#d0d000")}
        </PieChart>
      </ResponsiveContainer>
    </>
  );
}
