import { Typography } from "@mui/material";
import React from "react";
import { PieChart, Pie, Cell, Legend, ResponsiveContainer } from "recharts";

const FeedbackChart = ({ fbData }) => {
  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    index,
    fill,
  }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 2.2;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill={fill}
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };
  const data = Object.entries(fbData.feedbackRatingCount).map(
    ([name, value]) => ({
      name,
      value: Number(value),
    })
  );
  console.log("---", Object.entries(fbData.feedbackRatingCount));
  const COLORS = ["green", "#97de10", "lightgrey", "#d86e6e", "red"];

  return (
    <>
      <Typography
        sx={{
          fontSize: "22px",
          fontWeight: 700,
        }}
      >
        Sentiment Score
      </Typography>
      <ResponsiveContainer width={310} height={290}>
        <PieChart>
          <Pie
            data={data}
            cx={140}
            cy={120}
            innerRadius={60}
            outerRadius={80}
            fill="#8884d8"
            stroke="white"
            label={renderCustomizedLabel}
          >
            {data.map((entry, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </>
  );
};

export default FeedbackChart;
