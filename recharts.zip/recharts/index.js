import React from "react";
import App from "./App";

const index = () => {
  return <App />;
};

export default index;
